<?php





$start_time = new \DateTime(date('Y-m-d H:i:s'), new \DateTimeZone('America/Chicago'));

var_dump($start_time);