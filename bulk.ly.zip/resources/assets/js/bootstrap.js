window.$ = window.jQuery = require('jquery');
require('bootstrap-sass');

