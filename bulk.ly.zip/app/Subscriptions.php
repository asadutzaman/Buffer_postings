<?php

namespace Bulkly;

use Illuminate\Database\Eloquent\Model;

class Subscriptions extends Model
{
    //
}
